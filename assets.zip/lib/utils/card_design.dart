import 'package:flutter/widgets.dart';
import 'package:difog/utils/app_config.dart';

Decoration decoration = BoxDecoration(
  //color: MyColors.cardBackground,

  borderRadius: BorderRadius.circular(20),

  gradient: AppConfig.containerGradient,

);